let timerInterval;

const question = document.getElementById("question");
const choices = Array.from(document.getElementsByClassName("choice-text"));
const progressText = document.getElementById("progressText");
const scoreText = document.getElementById("score");
const progressBarFull = document.getElementById("progressBarFull");
const timerDisplay = document.getElementById("timer");
let currentQuestion = {};
let acceptingAnswers = false;
let score = 0;
let questionCounter = 0;
let availableQuestions = [];

let questions = [
  {
    question: "Which of the following attribute triggers an abort event?",
    choice1: "offline 1",
    choice2: "onabort",
    choice3: "abort",
    choice4: "onbeforeonload",
    answer: 3
  },
  {
    question: "Which of the following is true about 'video' tag in HTML5?",
    choice1: "MPEG4 files with H.264 video codec and AAC audio codec are supported. A",
    choice2: "Option You can use <source> tag to specify media along with media type and many other attributes",
    choice3: "C - An video element allows multiple source elements and browser will use the first recognized format",
    choice4: "All of the above.",
    answer: 4
  },
  {
    question: "Which of the following tag represents a piece of content that is only slightly related to the rest of the page in HTML5?",
    choice1: "true",
    choice2: "false",
    answer: 1
  },
  {
    question: "Which of the following input control is used for input fields that should contain an e-mail address in Web Form 2.0?",
    choice1: "emalil",
    choice2: "url",
    choice3: "Number",
    choice4: "reange",
    answer: 1
  },
  {
    question: "Which of the following attribute triggers event when an element is being dragged over a valid drop target?",
    choice1: "Ondragleave",
    choice2: "Ondrag",
    choice3: "Ondragover",
    choice4: "Ondragstarts",
    answer: 3
  },
  {
    question: "Which of the following browser supports HTML5 in its latest version? ",
    choice1: "Apple Safari",
    choice2: "Google Chrome",
    choice3: "Both of the above.",
    choice4: "None of the above",
    answer: 3
  },
  {
    question: "Which of the following method retrieves the current geographic location of the user?",
    choice1: "geolocation.getCurrentPosition()",
    choice2: "geolocation.watchPosition()",
    choice3: "geolocation.clearPosition()",
    choice4: "None of the above.",
    answer: 1
  },
  {
    question: "Which of the following attribute triggers event when an element has been dragged to a valid drop target?",
    choice1: "ondragleave",
    choice2: "ondrag",
    choice3: "ondragend",
    choice4: "ondragenter",
    answer: 4
  },
  {
    question: "Which of the following attribute triggers event when the document goes offline?",
    choice1: "onloadedmetadata",
    choice2: "onloadstart",
    choice3: "onmessage",
    choice4: "onoffline",
    answer: 4
  },
  {
    question: "Which of the following attribute triggers event when an element leaves a valid drop target?",
    choice1: "ondrag",
    choice2: "ondragleave",
    choice3: "ondragover",
    choice4: "ondragstart",
    answer: 2
  }
];

const CORRECT_BONUS = 1;
const MAX_QUESTIONS = 10;
const QUESTION_TIME = 10; // Time for each question in seconds

startGame = () => {
    questionCounter = 0;
    score = 0;
    availableQuestions = [...questions];
    getNewQuestion();
};

startTimer = () => {
    let timeLeft = QUESTION_TIME; // Initial time for each question

    timerDisplay.innerText = `${timeLeft} seconds`; // Display initial time

    timerInterval = setInterval(() => {
        timeLeft--;
        timerDisplay.innerText = `${timeLeft} seconds`; // Update timer display

        if (timeLeft === 0) {
            clearInterval(timerInterval); // Stop the timer
            getNewQuestion(); // Move to the next question
        }
    }, 1000);
};

resetTimer = () => {
    clearInterval(timerInterval); // Reset timer
    timerDisplay.innerText = ''; // Clear timer display
};

getNewQuestion = () => {
    resetTimer(); // Reset timer on new question

    if (availableQuestions.length === 0 || questionCounter >= MAX_QUESTIONS) {
        // Redirect to the end page with the score
        const finalScore = score * 10; // Assuming each correct answer is worth 10 points
        window.location.href = `/end.html?score=${finalScore}`;
        return;
    }
    questionCounter++;
    progressText.innerText = `Question ${questionCounter}/${MAX_QUESTIONS}`;
    progressBarFull.style.width = `${(questionCounter / MAX_QUESTIONS) * 100}%`;

    const questionIndex = Math.floor(Math.random() * availableQuestions.length);
    currentQuestion = availableQuestions[questionIndex];
    question.innerText = currentQuestion.question;

    choices.forEach(choice => {
        const number = choice.dataset["number"];
        choice.innerText = currentQuestion["choice" + number];
    });

    availableQuestions.splice(questionIndex, 1);
    acceptingAnswers = true;

    startTimer(); // Start the timer for the new question
};

choices.forEach(choice => {
    choice.addEventListener("click", e => {
        if (!acceptingAnswers) return;

        acceptingAnswers = false;
        resetTimer(); // Reset timer when user selects an answer

        const selectedChoice = e.target;
        const selectedAnswer = selectedChoice.dataset["number"];

        const classToApply = selectedAnswer == currentQuestion.answer ? "correct" : "incorrect";

        if (classToApply === "correct") {
            incrementScore(CORRECT_BONUS);
        }

        selectedChoice.parentElement.classList.add(classToApply);

        setTimeout(() => {
            selectedChoice.parentElement.classList.remove(classToApply);
            getNewQuestion();
        }, 1000);
    });
});

incrementScore = num => {
    score += num;
    scoreText.innerText = score;
};

startGame();