 // Define a function to retrieve and display the username
 function displayUsername() {
    // Retrieve the username from local storage
    const username = localStorage.getItem('username');

    // Get the element where we want to display the username
    const usernameElement = document.getElementById('usernameDisplay');

    // Check if username exists and the display element is found
    if (username && usernameElement) {
        // Display the username
        usernameElement.innerText = `Welcome, ${username}!`;
    } else {
        console.log('No username found or username display element not found.');
    }
}

// Call displayUsername when the DOM content is loaded
document.addEventListener('DOMContentLoaded', function() {
    displayUsername();
});