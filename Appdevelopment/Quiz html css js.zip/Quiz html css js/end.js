const finalScoreDisplay = document.getElementById("final-score");

// Get the score from the URL query parameter
const urlParams = new URLSearchParams(window.location.search);
const score = urlParams.get("score");

// Display the final score
finalScoreDisplay.textContent = `Your Final Score: ${score}`;
